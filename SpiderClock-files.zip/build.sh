#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
SDK="$PREFIX/share/aapt/android.jar"
[ -f "$SDK" ] || { echo "Missing Android library: $SDK"; exit 1; }
command -v javac >/dev/null; command -v d8 >/dev/null; command -v aapt >/dev/null; command -v zipalign >/dev/null; command -v apksigner >/dev/null; command -v keytool >/dev/null
rm -rf build gen unsigned.apk aligned.apk SpiderClock.apk
mkdir -p build/classes gen
# Generate resource IDs and packaged resources
aapt package -f -m -J gen -M AndroidManifest.xml -S res -I "$SDK" --min-sdk-version 23 --target-sdk-version 28
javac -source 8 -target 8 -classpath "$SDK" -d build/classes gen/com/spiderclock/widget/R.java src/com/spiderclock/SpiderClockWidget.java
d8 --lib "$SDK" --min-api 23 --output build build/classes/com/spiderclock/SpiderClockWidget.class
# Include generated inner/anonymous classes if any; D8 output is classes.dex
# Repackage app resources and manifest
aapt package -f -M AndroidManifest.xml -S res -I "$SDK" --min-sdk-version 23 --target-sdk-version 28 -F unsigned.apk
(cd build && zip -q -u ../unsigned.apk classes.dex)
zipalign -f 4 unsigned.apk aligned.apk
if [ ! -f debug.keystore ]; then keytool -genkeypair -keystore debug.keystore -storepass android -alias androiddebugkey -keypass android -dname 'CN=Android Debug,O=Android,C=US' -keyalg RSA -keysize 2048 -validity 10000 >/dev/null 2>&1; fi
apksigner sign --ks debug.keystore --ks-pass pass:android --key-pass pass:android --out SpiderClock.apk aligned.apk
apksigner verify SpiderClock.apk
 echo
 echo 'SUCCESS! APK created:' "$PWD/SpiderClock.apk"
