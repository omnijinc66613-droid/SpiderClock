package com.spiderclock;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.RectF;
import java.util.Calendar;

public class SpiderClockWidget extends AppWidgetProvider {
 @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for(int id:ids) update(c,m,id); }
 public static void update(Context c, AppWidgetManager m, int id) {
  Bitmap b=drawClock(); RemoteViews v=new RemoteViews(c.getPackageName(), com.spiderclock.widget.R.layout.widget);
  v.setImageViewBitmap(com.spiderclock.widget.R.id.clock_image,b); m.updateAppWidget(id,v);
 }
 static Bitmap drawClock(){
  final int S=900; Bitmap b=Bitmap.createBitmap(S,S,Bitmap.Config.ARGB_8888); Canvas c=new Canvas(b); c.drawColor(Color.BLACK);
  Paint p=new Paint(3); float cx=450,cy=450,r=390;
  // faint gold outer guide
  p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.rgb(48,29,15)); c.drawCircle(cx,cy,r,p);
  // dim golden hour numbers, matching reference
  p.setStyle(Paint.Style.FILL); p.setTypeface(Typeface.create("sans-serif-light",Typeface.NORMAL)); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(43); p.setColor(Color.rgb(82,48,20));
  for(int i=1;i<=12;i++){double a=Math.PI*(i/6.0)-Math.PI/2; float x=cx+(float)Math.cos(a)*320, y=cy+(float)Math.sin(a)*320+15; c.drawText(String.valueOf(i),x,y,p);}
  // three intricate web/gear rosettes
  rosette(c,365,380,74,p); rosette(c,535,380,74,p); rosette(c,425,525,47,p); rosette(c,485,570,65,p); rosette(c,450,305,45,p);
  // subtle spider silhouette glow
  p.setShadowLayer(22,0,0,Color.rgb(255,145,15)); p.setColor(Color.rgb(255,169,35)); p.setStyle(Paint.Style.FILL);
  c.drawOval(new RectF(427,390,473,455),p); c.drawCircle(450,382,20,p);
  // eight curved legs
  p.clearShadowLayer(); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(9); p.setStrokeCap(Paint.Cap.ROUND); p.setColor(Color.rgb(255,169,35));
  float[][] legs={{432,400,390,355,350,360},{430,414,385,398,348,420},{432,432,390,455,365,480},{438,445,410,485,400,500},{468,400,510,355,550,360},{470,414,515,395,555,415},{468,432,510,455,535,480},{462,445,490,480,500,500}};
  for(float[] q:legs){Path path=new Path();path.moveTo(q[0],q[1]);path.quadTo(q[2],q[3],q[4],q[5]);c.drawPath(path,p);}
  // hands: actual live time, warm restrained glow
  Calendar cal=Calendar.getInstance(); float sec=cal.get(Calendar.SECOND), min=cal.get(Calendar.MINUTE)+sec/60f, hr=(cal.get(Calendar.HOUR)%12)+min/60f;
  hand(c,cx,cy,hr/12f,170,7,Color.rgb(255,173,50)); hand(c,cx,cy,min/60f,245,5,Color.rgb(255,177,72)); hand(c,cx,cy,sec/60f,290,2,Color.rgb(235,123,42));
  p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(255,173,45));p.setShadowLayer(10,0,0,Color.rgb(255,145,15));c.drawCircle(cx,cy,8,p);p.clearShadowLayer();
  return b;
 }
 static void hand(Canvas c,float x,float y,float fraction,float len,float width,int color){double a=fraction*Math.PI*2-Math.PI/2; Paint p=new Paint(3);p.setColor(color);p.setStrokeWidth(width);p.setStrokeCap(Paint.Cap.ROUND);p.setShadowLayer(7,0,0,Color.rgb(210,95,20));c.drawLine(x,y,x+(float)Math.cos(a)*len,y+(float)Math.sin(a)*len,p);p.clearShadowLayer();}
 static void rosette(Canvas c,float x,float y,float r,Paint p){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.8f);p.setColor(Color.rgb(70,43,29)); for(int j=0;j<3;j++){Path path=new Path();for(int i=0;i<=240;i++){double a=i*Math.PI*2/240;double rr=r*(0.78+0.22*Math.cos(12*a+j*2.094));float px=x+(float)Math.cos(a)*rr,py=y+(float)Math.sin(a)*rr;if(i==0)path.moveTo(px,py);else path.lineTo(px,py);}c.drawPath(path,p);}p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(100,61,28));c.drawCircle(x,y,4,p);}
}
