SPIDER CLOCK - TERMUX BUILD

Build in Termux:
1. Extract this folder under ~/SpiderClockTermux (or another path).
2. cd ~/SpiderClockTermux
3. bash build.sh
4. Install with: termux-open SpiderClock.apk
   If that doesn't open the installer, copy the APK to Download and tap it in My Files.
5. Long-press home screen > Widgets > Spider Clock > drag it onto home screen.

The widget is drawn in code to resemble the provided reference: black background, dim gold numbers, central golden spider, faint web/gear rosettes and gold analog hands. Android widgets are refreshed by the launcher/system; this basic version requests standard widget refreshes and may not tick every minute on every device.
